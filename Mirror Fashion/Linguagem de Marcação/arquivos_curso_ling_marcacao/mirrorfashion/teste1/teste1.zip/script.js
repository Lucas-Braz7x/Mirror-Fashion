  var original = "Porco";
        function atualiza(){
           window.location = ("http://www.google.com");
        }
        function soma(){
            var v1 = Number(document.getElementById("v1").value);
            var v2 = Number(document.getElementById("v2").value);
            document.getElementById("texto").innerHTML = "soma="+(v1+v2); 
            
        }
        function troca_cor(){
            document.getElementById("texto").innerHTML = original;
            document.getElementById("texto").style.color ="purple";
        }
        function Add(){
            document.getElementById("itens").innerHTML = 
            document.getElementById("itens").innerHTML +
            '<p style="color:blue;font-size:30;">'+
            document.getElementById("v1").value+'</p>';
        }